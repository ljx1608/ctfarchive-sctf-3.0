# Turbo Fast Crypto II
The challenge service running is `tfc.py`. It imports the `turbofastcrypto` library from the long `turbofastcrypto-cpython....so` file. `turbofastcrypto.c` is the source code for said library, and you can compile it yourself (along with any changes you wish to insert) using `./compile.sh`.

**A first blood prize of one (1) month of Discord Nitro is available for this challenge**, as determined by public vote.
