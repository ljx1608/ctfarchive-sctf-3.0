<?php
  session_start();

  try {
    if (empty($_POST["token"])) {
      if (empty($_SESSION["email"]) || !($_SESSION["email"] === "taiyang.it.solution@gmail.com")) {
        echo "You are not a verified TaiYang IT Solution employee or partner. Please log out and login again with the correct account!";
        $_SESSION["email"] = "";
      }
      else {
        echo "Welcome to IT Solution portal! Here is a flag: IRS{FLAG_REDACTED}";
      }
    }
    else {
      $data1 = explode(".", $_POST["token"]);
      $data2 = base64_decode($data1[1]);
      $data3 = json_decode($data2, true);
      $_SESSION["email"] = $data3["email"];
      die("ok");
    }
  }
  catch (Exception $e) {
    die("Oh no! Error.");
  }

  // https://firebase.google.com/docs/auth/admin/verify-id-tokens
?>

<a href="javascript:signOut();">Sign Out</a>

<script src="https://www.gstatic.com/firebasejs/8.6.7/firebase-app.js"></script>
<script src="https://www.gstatic.com/firebasejs/8.6.7/firebase-auth.js"></script>

<script>
  const firebaseConfig = {
    apiKey: "AIzaSyBuTxFM_UujACXk9ijQYrpK4W87EhJYn24",
    authDomain: "sieberrctf-jwt-chall.firebaseapp.com",
    projectId: "sieberrctf-jwt-chall",
    storageBucket: "sieberrctf-jwt-chall.appspot.com",
    messagingSenderId: "536225190082",
    appId: "1:536225190082:web:d1b5e5d1b7fbf3b29cab5b"
  };

  // Initialize Firebase
  const app = firebase.initializeApp(firebaseConfig);

  var provider = new firebase.auth.GoogleAuthProvider();

  function signOut() {
    firebase.auth().signOut().then(() => {
      location.href = "login.html";
    }).catch((error) => {
      // An error happened.
    });
  }
</script>